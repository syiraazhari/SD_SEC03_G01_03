<!DOCTYPE html>
<html lang="en-US">
<head>
<title>Stripe Payment Status - codeat21 </title>
<meta charset="utf-8">
<!-- Stylesheet file -->
<link href="css/style.css" rel="stylesheet">
</head>
<body class="App">
  <h1>Your transaction was canceled!</h1>
	<div class="wrapper">
		<a href="index.php" class="btn-link">Back to Product Page</a>
	</div>
</body>
</html>