<?php

    $dbcon=mysqli_connect("localhost", "root", "", "sd_g01_03");  
    mysqli_select_db($dbcon,"users");  

?>